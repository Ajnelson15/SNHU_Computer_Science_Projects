#ifndef CORNERGROCER_H
#define CORNERGROCER_H

class CornerGrocer { 

public:
	void displayMenu();						//Displays menu options for program
	void getItemCount();					//Searches for user selected item and returns amount sold for the day
	void getMenuChoice(int choice);			//Handles users input for menu options
	void printList();						//Prints list of all items with the total number sold for the day
	void printHistogram();					//Prints histogram of the items and number sold for the day
	void writeFile();						//Writes a backup file of the days inventory
};
#endif
