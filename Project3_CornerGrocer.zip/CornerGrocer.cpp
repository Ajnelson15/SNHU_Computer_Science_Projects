#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <algorithm>
#include <map>
#include "CornerGrocer.h"
using namespace std;

void CornerGrocer::displayMenu()		//Main Menu display
{
	cout << "----------------------------\n";
	cout << "CORNER GROCER INVENTORY MENU\n";
	cout << "----------------------------\n";
	cout << "  1. Look up items\n";
	cout << "  2. Print items list\n";
	cout << "  3. Print items histogram\n";
	cout << "  4. Exit the program\n";
	cout << "----------------------------\n";
	cout << "  Please select an option\n";
}

void CornerGrocer::getItemCount()	//Searches for user selected item and returns amount sold for the day
{
	int wordFreq = 0;	//Counter for each item sold
	string currWord;	//Variable for current word to be read in from the file
	string item;		//Variable to hold user's input
	ifstream inFile;	//Input stream allowing to read information contained in file

	inFile.open("CS210_Project_Three_Input_File.txt");	//Opens desired txt file

	//Verfies the file opened
	if (!inFile.is_open()) {
		cout << "Could not open file CS210_Project_Three_Input_File.txt" << endl;
	}
	//Prompt user for item to be located
	cout << "Enter the item you wish to locate.\n";
	cin >> item;
	//Formats input to match files format of words.
	transform(item.begin(), item.end(), item.begin(), ::tolower);	//Changes input to all lowercase letters
	item[0] = toupper(item[0]);		//Capitalizes first letter of input
	cout << endl;

	//Reads file until the end of file is reached
	while (!inFile.eof()) {
		inFile >> currWord;	//Reads current word in file

		//Until end of file is reached  
		if (!inFile.fail()) {		
			if (currWord == item) {		//If current word is the same as users item
				++wordFreq;				//Increment that word frequency
			}
		}
	}
	//Prints formatted number of user's items
	cout << "---------------------\n";
	cout << "ITEMS SOLD TODAY     \n";
	cout << "---------------------\n\n";
	cout << wordFreq << " " << item << endl;
	inFile.close();
	cout << endl;
	system("pause");
	system("cls");


}

void CornerGrocer::getMenuChoice(int choice)
{
	
	// Main Menu options for user input

	if (choice == 1) {
		system("cls");
		getItemCount();
	}
	if (choice == 2) {
		system("cls");
		printList();
	}
	if (choice == 3) {
		system("cls");
		printHistogram();
	}
	if (choice == 4) {
		system("cls");
		cout << " Good Bye...\n";
	}
}

void CornerGrocer::printList()
{
	map<string, int> itemsPurchased;	//Map to hold file data in key and values
	ifstream inFile;	//Stream to read in file
	string item;	//Variable to hold items

	inFile.open("CS210_Project_Three_Input_File.txt");		//Opens txt file to read

	//Checks if file is open
	if (!inFile.is_open()) {
		cout << "Could not open file CS210_Project_Three_Input_File.txt" << endl;
	}
	//Prints header
	cout << "-----------------------\n";
	cout << "   TODAY'S PURCHASES\n";
	cout << "-----------------------\n\n";

	//Creates map of items and total count
	while (inFile >> item) {
		if (itemsPurchased.count(item)) { //If item is on the list, add one to item count 
			itemsPurchased[item]++;
		}
		else {
			itemsPurchased.emplace(item, 1);	//If item not on list, add to list and start count at 1
		}
	}
	// Prints each item followed by the number sold for the day
	for (auto list : itemsPurchased) {
		cout << "   " << setw(15) << left << list.first << " " << setw(10) << left << list.second << endl;

		//Closes file
		inFile.close();
	}
	cout << endl;
	system("pause");
	system("cls");
}

void CornerGrocer::printHistogram()
{
	map<string, int> itemsPurchased;
	ifstream inFile;
	string item;


	//Opens file
	inFile.open("CS210_Project_Three_Input_File.txt");

	//Checks if file is open
	if (!inFile.is_open()) {
		cout << "Could not open file CS210_Project_Three_Input_File.txt" << endl;
	}

	//Creates map of items and total count
	while (inFile >> item) {
		if (itemsPurchased.count(item)) {
			itemsPurchased[item]++;		//Adds 1 to existing items
		}
		else {
			itemsPurchased.emplace(item, 1);	//Adds item if not mapped
		}

	}
	cout << endl;

	// Prints histogram version of items and count
	for (auto list : itemsPurchased) {
		cout << right << std::setw(15);
		cout << list.first;
		//Prints an asterik equal to the count
		for (int i = 0; i < list.second; ++i) {	
			cout << "*";
		}
		cout << endl;
	}
	inFile.close(); //Closes file
	cout << endl;
	system("pause");
	system("cls");
}

void CornerGrocer::writeFile()	//Writes a file for backup
{
	map<string, int> itemsPurchased;
	ifstream inFile;
	string item;

	inFile.open("CS210_Project_Three_Input_File.txt");	//Opens file to read

	//Checks if file is open
	if (!inFile.is_open()) {
		cout << "Could not open file CS210_Project_Three_Input_File.txt" << endl;
	}
	//Creates map with item and total count
	while (inFile >> item) {
		if (itemsPurchased.count(item)) {
			itemsPurchased[item]++;
		}
		else {
			itemsPurchased.emplace(item, 1);
		}

	}
	//Closes file
	inFile.close();

	
	ofstream outFile;	//Creates stream to write to file
	outFile.open("frequency.dat");	//Opens file to write

	//Checks if file is open
	if (!outFile.is_open()) {
		cout << "Could not open file frequency.dat";
	}
	//Writes items and total count to the file
	for (auto list : itemsPurchased) {
		outFile << list.first << " " << list.second << endl;
	}
	//Closes file
	outFile.close();
}
