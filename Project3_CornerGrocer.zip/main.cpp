#include <iostream>
#include "CornerGrocer.h"

using namespace std;

int choice;

int main() {
	
	CornerGrocer day1;
	day1.writeFile();	//Reads file in and writes a backup of the data

	//Loop to run program until user wants to exit
	while (choice != 4) {
		
		day1.displayMenu();	//Displays main menu
		cin >> choice;	//Prompts user for menu choice
		
		//Validates user input for main menu
		while (choice <= 0 || choice > 5 || cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << "Invalid Entry. Please select valid option.\n";
			cin >> choice;
		}
		day1.getMenuChoice(choice);		//Runs menu based of user's choice 
	}
	return 0;	//Closes program
}
